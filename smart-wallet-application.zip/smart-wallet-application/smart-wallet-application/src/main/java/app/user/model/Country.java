package app.user.model;

public enum Country {
    BULGARIA, GERMANY, FRANCE
}