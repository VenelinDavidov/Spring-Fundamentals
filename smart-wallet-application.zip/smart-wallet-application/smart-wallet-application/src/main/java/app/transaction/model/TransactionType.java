package app.transaction.model;

public enum TransactionType {
    DEPOSIT, WITHDRAWAL
}