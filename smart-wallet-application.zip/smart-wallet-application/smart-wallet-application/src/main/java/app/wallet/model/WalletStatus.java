package app.wallet.model;

public enum WalletStatus {

    ACTIVE, INACTIVE;
}