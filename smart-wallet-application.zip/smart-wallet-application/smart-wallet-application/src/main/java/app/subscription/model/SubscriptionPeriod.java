package app.subscription.model;

public enum SubscriptionPeriod {

    MONTHLY, YEARLY;
}