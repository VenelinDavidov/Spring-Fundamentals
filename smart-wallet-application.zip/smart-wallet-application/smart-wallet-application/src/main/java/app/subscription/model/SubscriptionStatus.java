package app.subscription.model;

public enum SubscriptionStatus {
    ACTIVE, COMPLETED, TERMINATED
}