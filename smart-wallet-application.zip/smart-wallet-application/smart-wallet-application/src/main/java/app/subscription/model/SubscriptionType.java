package app.subscription.model;

public enum SubscriptionType {
    DEFAULT, PREMIUM, ULTIMATE
}